CREATE TABLE Rayon (  
nom_rayon VARCHAR	 (20) NOT NULL ,  
no_rayon  INTEGER  NOT NULL primary key, 
nom_employe VARCHAR (20)   NOT NULL REFERENCES Employe (nom_employe) ON DELETE CASCADE 
);  