CREATE TABLE Commandes (  
no_com  INTEGER NOT NULL PRIMARY KEY  ,  
date_com  DATE  NOT NULL ,  
nom_client  VARCHAR	 (20)  NOT NULL   ,  
FOREIGN KEY (nom_client) REFERENCES Client (nom_client) ON DELETE CASCADE
);  