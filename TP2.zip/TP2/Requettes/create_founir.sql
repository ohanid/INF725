CREATE TABLE Fournir (  
nom_four  VARCHAR	 (20)  NOT NULL ,  
ref_prod  INTEGER NOT NULL ,  
prix NUMERIC  NOT NULL, 
PRIMARY KEY (nom_four, ref_prod),
FOREIGN KEY (nom_four) REFERENCES Fournisseur (nom_four)  ON DELETE CASCADE, 
FOREIGN KEY (ref_prod) REFERENCES Produit (ref_prod)  ON DELETE CASCADE
);  