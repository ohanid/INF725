CREATE TABLE Ligne_com (  
no_com  INTEGER NOT NULL ,
ref_prod  INTEGER  NOT NULL ,
quantite NUMERIC  NOT NULL ,
PRIMARY KEY (no_com, ref_prod) , 
FOREIGN KEY (no_com) REFERENCES Commandes (no_com)  ON DELETE CASCADE, 
FOREIGN KEY (ref_prod) REFERENCES Produit (ref_prod)  ON DELETE CASCADE
);  