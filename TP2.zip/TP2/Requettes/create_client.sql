CREATE TABLE Client (  
nom_client  VARCHAR	 (20)  NOT NULL PRIMARY KEY  ,  
adresse_client  VARCHAR	 (20)  NOT NULL ,  
solde NUMERIC  NOT NULL
);  