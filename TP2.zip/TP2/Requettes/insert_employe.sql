INSERT INTO Employe values  ("durand", 1000, null);
INSERT INTO Employe values  ("dubois", 1500, null);
INSERT INTO Employe values  ("dupont", 2000,null);
INSERT INTO Employe values  ("dumoulin", 1200, null);
INSERT INTO Employe values  ("dutilleul", 1000, null);
INSERT INTO Employe values  ("duchene", 2000,  null);
INSERT INTO Employe values  ("duguesclin", 1500, null);
INSERT INTO Employe values  ("duduche", 2000, null);