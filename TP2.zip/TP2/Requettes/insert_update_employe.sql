UPDATE Employe SET no_rayon =  1 WHERE nom_employe = "durand" ;
UPDATE Employe SET no_rayon =  1 WHERE nom_employe = "dubois" ;
UPDATE Employe SET no_rayon =  1 WHERE nom_employe = "dupont" ;
UPDATE Employe SET no_rayon =  2 WHERE nom_employe = "dumoulin" ;
UPDATE Employe SET no_rayon =  2 WHERE nom_employe = "dutilleul" ;
UPDATE Employe SET no_rayon =  2 WHERE nom_employe = "duchene" ;
UPDATE Employe SET no_rayon =  3 WHERE nom_employe = "duguesclin" ;
UPDATE Employe SET no_rayon =  3 WHERE nom_employe = "duduche" ;