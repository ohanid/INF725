CREATE TRIGGER check_price BEFORE INSERT ON Produit 
WHEN Produit.prix_vente < 0
BEGIN
SELECT RAISE(ABORT, 'You can''t add negative prices');
END;
