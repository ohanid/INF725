CREATE TABLE Employe (  
nom_employe VARCHAR (20) NOT NULL PRIMARY KEY,  
salaire  NUMERIC NOT NULL,  
no_rayon INTEGER REFERENCES Rayon (no_rayon)  ON DELETE CASCADE 
);  