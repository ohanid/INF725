DELETE FROM Client 
WHERE nom_client='dupont' 