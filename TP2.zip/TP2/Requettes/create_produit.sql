CREATE TABLE Produit (  
nom_Prod  VARCHAR	 (20)  NOT NULL ,  
ref_prod  INTEGER  NOT NULL PRIMARY KEY,  
no_rayon INTEGER  NOT NULL, 
 prix_vente NUMERIC  NOT NULL,  
FOREIGN KEY (no_rayon) REFERENCES Rayon (no_rayon)  ON DELETE CASCADE
);  