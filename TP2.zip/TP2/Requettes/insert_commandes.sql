INSERT INTO Commandes values  (1, '01-01-2013' , "dupont");
INSERT INTO Commandes values  (2, '2014-01-05', "dupond");
INSERT INTO Commandes values  (3, '2014-01-18',"dupont");
INSERT INTO Commandes values  (4, '2014-01-25', "dumas");
INSERT INTO Commandes values  (5, '2015-01-31', "dumas");