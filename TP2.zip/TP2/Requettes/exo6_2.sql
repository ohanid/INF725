DELETE FROM Client 
WHERE nom_client not in ( Select Client.nom_client FROM Client JOIN Commandes ON Client.nom_client = Commandes.nom_client ) 