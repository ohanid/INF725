INSERT INTO Client values  ("dumont",	"paris",	500);
INSERT INTO Client values  ("dupont", "lyon", -200);
INSERT INTO Client values  ("dupond", "marseille",-300);
INSERT INTO Client values  ("dulac", "paris", 800);
INSERT INTO Client values  ("dumas", "lyon", -300);
