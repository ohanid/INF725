INSERT INTO Produit values  ("train", 1, 1, 100);
INSERT INTO Produit values  ("avion", 2	, 1 ,	75);
INSERT INTO Produit values  ("bateau", 3	,1	,70);
INSERT INTO Produit values  ("pantalon", 4	, 2	, 30);
INSERT INTO Produit values  ("veste", 5	,2	,38);
INSERT INTO Produit values  ("robe", 6	, 2	, 50);
INSERT INTO Produit values  ("rateau",  7,	3,	5);
INSERT INTO Produit values  ("pioche",  8,	3,	7);
INSERT INTO Produit values  ("brouette",  9,	3, 38);