INSERT INTO Rayon values  ("jouet", 1, "dupont");
INSERT INTO Rayon values  ("vetement", 2, "duchene");
INSERT INTO Rayon values  ("jardin", 3,"duduche");