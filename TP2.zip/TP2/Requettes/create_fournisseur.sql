CREATE TABLE Fournisseur(  
nom_four  VARCHAR (20)  NOT NULL PRIMARY KEY ,  
adresse_four  VARCHAR (230) 
);  