INSERT INTO Fournisseur values  ("f1", "paris");
INSERT INTO Fournisseur values  ("f2", "lyon");
INSERT INTO Fournisseur values  ("f3", "marseille");